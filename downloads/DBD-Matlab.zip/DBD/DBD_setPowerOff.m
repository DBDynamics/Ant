function DBD_setPowerOff(id)
%DBD_POWERON PowerOff the Device
%   id: the device id you want to power off
global DBD;
DBD_SendMessage(DBD.FUNC_CODE_TSDO, id, DBD.INDEX_CONTROL_WORD, DBD.SUBINDEX_WRITE, 0);
end

