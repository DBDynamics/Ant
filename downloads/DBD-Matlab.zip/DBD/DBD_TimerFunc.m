function DBD_TimerFunc(obj, event)
global DBD;
DBD.timerCounter = DBD.timerCounter +1;
% disp(DBD.timerCounter);
DBD_LinkProcess();
end

