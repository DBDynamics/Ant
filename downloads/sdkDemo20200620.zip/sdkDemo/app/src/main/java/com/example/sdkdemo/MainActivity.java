package com.example.sdkdemo;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.SystemClock;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.example.dbdriver.DBDActivity;
import com.example.dbdriver.DBDMotorCallback;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Objects;

public class MainActivity extends DBDActivity
{
    DBDActivity myMotor = new DBDActivity();

    /* variable for testing */
    dThread demoThread;
    int[] targetReachedFlag = new int[121];

    UsbManager manager;

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myMotor.scanUSB(this, (UsbManager) getSystemService(Context.USB_SERVICE));

        /* for testing */
        demoThread = new dThread("demo");
        demoThread.start();
    }


    /* Callback */
    class Callback implements DBDMotorCallback
    {
        @Override
        public void onTargetReachedCallback(int id, int subid)
        {
            Log.i("motion", "callback success: " + id);
            targetReachedFlag[id] = 1;
        }
    }


    /* for testing */
    class dThread extends Thread
    {
        public dThread(String name)
        {
            super(name);
        }

        @Override
        public void run()
        {
            int delay = 50;

            int tpa1 = -50000 * 14 / 2;
            int tpa2 = 50000 * 3 / 2;
            int tpb1 = -50000 * 14 / 4;
            int tpb2 = 50000 * 3 / 4;
            myMotor.waitUSBReady();

            Log.i("motion", "demo start");
            int counter = 100000;
            int channel = -1;

            int rs485Channel = -1;

            if (myMotor.isChannelTypeCAN(0))
            {
                channel = 0;
            }
            if (myMotor.isChannelTypeCAN(1))
            {
                channel = 1;
            }

            if (myMotor.isChannelTypeRS485(0))
            {
                rs485Channel = 0;
            }
            if (myMotor.isChannelTypeRS485(1))
            {
                rs485Channel = 1;
            }
            Log.i("motion", "CAN Channel: "+channel);
            Log.i("motion", "RS485 Channel: "+rs485Channel);
            for (int i = 0; i < 8; i++)
            {
                myMotor.setHeartBeatRate(channel, i + 1, 0, 0);
            }

            for (int i = 0; i < 8; i++)
            {
                myMotor.setEnable(channel, 1 + i, 0, 1);
            }

            for (int i = 0; i < 8; i++)
            {
                myMotor.setPos(channel, 1 + i, 0, -5000);
            }

            for (int i = 0; i < 8; i++)
            {
                myMotor.waitTargetReached(channel, 1 + i, 0, 5, 200);
            }

            for (int i = 0; i < 8; i++)
            {
                myMotor.setHomingLevelHigh(channel, 1 + i, 0);
            }

            for (int i = 0; i < 8; i++)
            {
                myMotor.setSpeed(channel, 1 + i, 0, 20);
            }

            Log.i("motion", "homing start");
            for (int i = 0; i < 8; i++)
            {
                myMotor.setOpModeHoming(channel, 1 + i, 0);
            }
            for (int i = 0; i < 8; i++)
            {
                myMotor.waitTargetReached(channel, 1 + i, 0, 3, 200);
            }
            Log.i("motion", "homing done");

            myMotor.setPegPowerOn(rs485Channel,1,0);
            myMotor.setPegTargetTemp(rs485Channel,1,0,2000);
            myMotor.setPegTriggerRange(rs485Channel,1,0,20);
            while (true)
            {
                for (int i = 0; i < 8; i++)
                {
                    myMotor.setPos(channel, 1 + i, 0, -50000);
                }

                for (int i = 0; i < 8; i++)
                {
                    myMotor.waitTargetReached(channel, 1 + i, 0, 2, 200);
                }

                for (int i = 0; i < 8; i++)
                {
                    myMotor.setPos(channel, 1 + i, 0, 50000);
                }

                for (int i = 0; i < 8; i++)
                {
                    myMotor.waitTargetReached(channel, 1 + i, 0, 2, 200);
                }

                Log.i("motion", "actual temp is: "+myMotor.getPegActualTemp(rs485Channel,1,0));
            }
        }
    }
}
