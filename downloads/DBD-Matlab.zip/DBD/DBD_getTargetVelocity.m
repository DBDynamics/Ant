function ret = DBD_getTargetVelocity(id)
%ret = DBD_getTargetVelocity(id) ���ú�����ȡĿ���ٶ�
%   id:1 - 120
%   ret: ����ֵ
global DBD;
DBD_SendMessage(DBD.FUNC_CODE_TSDO, id, DBD.INDEX_TARGET_VELOCITY, DBD.SUBINDEX_READ, 0);
pause(0.05)%wait some time for rx message analysis and value update
ret = DBD.motors(id+1,DBD.INDEX_TARGET_VELOCITY+1);
end

