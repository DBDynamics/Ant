function DBD_Stop()
%DBD_STOP Stop DB-LINK back gound process
%   Stop DB-LINK back gound process
global DBD;
stop(DBD.timer);
fclose(DBD.serialport)
delete(DBD.serialport)
disp('DB-Link stoped');
end

