function DBD_setHomingLevel(id,value)
%DBD_setHomingLevel(id,value) ���ô˺������û���ģʽ�Ĵ�����ƽ
%   id: 1-120
%   value: 1-�ߵ�ƽ or 0-�͵�ƽ
global DBD;
if(value == 1)
    DBD_SendMessage(DBD.FUNC_CODE_TSDO, id, DBD.INDEX_HOMING_LEVEL, DBD.SUBINDEX_WRITE, 1);
elseif(value == 0)
    DBD_SendMessage(DBD.FUNC_CODE_TSDO, id, DBD.INDEX_HOMING_LEVEL, DBD.SUBINDEX_WRITE, 0);
else
    disp('Please Check Your Parameters, 1 or 0');
end
end

