package com.example.dbdriver;

public interface CallBackInterface
{
    void onNoUSBConnected();
}
