package com.example.testdemo001;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.dbdriver.DBDActivity;

public class MainActivity extends AppCompatActivity
{

    DBDActivity myMotor = new DBDActivity();

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myMotor.handleIntent(getIntent(), this.<UsbManager>getSystemService(UsbManager.class), myMotor.BoardTypeBee);

        final Button ba = findViewById(R.id.button_a);
        final Button bb = findViewById(R.id.button_b);
        final Button bon = findViewById(R.id.button_on);
        final Button boff = findViewById(R.id.button_off);
        final Button b_mode = findViewById(R.id.button_mode);
        final Button b_home = findViewById(R.id.button_home);
        final Button b_run = findViewById(R.id.button_run);

        ba.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                // Code here executes on main thread after user presses button
                myMotor.setPos(1,0, 50000);
            }
        });
        bb.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                // Code here executes on main thread after user presses button
                myMotor.setPos(1,0, -0);
            }
        });
        bon.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                // Code here executes on main thread after user presses button
                myMotor.setEnable(1,0,1);
            }
        });
        boff.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                // Code here executes on main thread after user presses button
                myMotor.setEnable(1,0,0);
            }
        });
        b_mode.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                // Code here executes on main thread after user presses button
                myMotor.setOpModeProfilePositon(1, 0);
            }
        });
        b_home.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                // Code here executes on main thread after user presses button
                myMotor.setVel(1, 0, 500);
                myMotor.setVel(2, 0, 500);
                myMotor.setVel(3, 0, 500);
                myMotor.setHomingLevelHigh(1, 0);
                myMotor.setHomingDirNegative(1, 0);
                myMotor.setHomingLevelHigh(2, 0);
                myMotor.setHomingDirNegative(2, 0);
                myMotor.setHomingLevelHigh(3, 0);
                myMotor.setHomingDirNegative(3, 0);
                myMotor.setOpModeHoming(1, 0);
                myMotor.setOpModeHoming(2, 0);
                myMotor.setOpModeHoming(3, 0);
            }
        });
        b_run.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View v)
            {
                // Code here executes on main thread after user presses button
                myMotor.setVel(1, 0, 1500);
                myMotor.setVel(2, 0, 1500);
                myMotor.setVel(3, 0, 1500);
                myMotor.setPos(1, 0, 5*51200);
                myMotor.setPos(2, 0,5*51200);
                myMotor.setPos(3, 0,5*51200);
            }
        });
    }
}
