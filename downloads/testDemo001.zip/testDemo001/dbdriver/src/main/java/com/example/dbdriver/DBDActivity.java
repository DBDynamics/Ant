package com.example.dbdriver;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.telecom.Call;
import android.util.Log;

import java.util.HashMap;
import java.util.Iterator;

public class DBDActivity extends AppCompatActivity
{
    public CallBackInterface CallBack;
    public void setUpCallback(CallBackInterface mCallBack)
    {
        CallBack =mCallBack;
    }
    private static final String TAG = "UsbEnumerator";
    public static final int FUNC_TSDO = 0X580;
    public static final int AntControlWordIndex = 0;
    public static final int AntModesofOperationIndex = 1;
    public static final int AntMemoryIndex = 30;
    public static final int AntDeviceIDIndex = 31;
    public static final int AntStepperCurrentRunIndex = 40;
    public static final int AntStepperCurrentKeepIndex = 42;
    public static final int AntStepperRunVelIndex = 48;
    public static final int AntStepperAccTimeIndex = 47;
    public static final int AntStepperHomeDirIndex = 45;
    public static final int AntStepperHomeLevelIndex = 46;
    public static final int AntStepperRunPosIndex = 49;
    public static final int AntStatusWordIndex = 50;
    public static final int AntActualPositionIndex = 53;
    public static final int AntWriteSubIndex = 0;
    public static final int AntReadSubIndex = 1;
    public static final int STATUS_TARGET_REACHED = 0x04;
    public static final int OPMODE_PROFILE_POSITION = 31;
    public static final int OPMODE_PROFILE_VELOCITY = 21;
    public static final int OPMODE_PROFILE_POSITION_SYNC = 33;
    public static final int OPMODE_PROFILE_VELOCITY_SYNC = 23;
    public static final int OPMODE_POSITION_ENCODER = 35;
    public static final int OPMODE_SENSOR_FLIP = 36;
    public static final int OPMODE_HOMING = 40;

    /* Profile for Stepper Bee */
    public static final int BeeBoardTypeIndex = 0;
    public static final int BeeDeviceIDIndex = 1;
    public static final int BeeControlWordIndex = 2;
    public static final int BeeOperationModeIndex = 3;
    public static final int BeeStatusWordIndex = 4;
    public static final int BeeTargetCurrentIndex = 5;
    public static final int BeeActualCurrentIndex = 6;
    public static final int BeeTargetVelocityIndex = 7;
    public static final int BeeActualVelocityIndex = 8;
    public static final int BeeTargetPositionIndex = 9;
    public static final int BeeActualPositionIndex = 10;
    public static final int BeeProfileAccTimeIndex = 11;
    public static final int BeeInterpolationTargetPostionIndex = 12;
    public static final int BeeHomingModeIndex = 13;
    public static final int BeeHomingDirIndex = 14;
    public static final int BeeHomingLevelIndex = 15;
    public static final int BeeHomingOffsetIndex = 16;
    public static final int BeeStepperCurrentRunIndex = 17;
    public static final int BeeStepperCurrentKeepIndex = 18;
    public static final int BeeStepperCurrentBoostIndex = 19;
    public static final int BeeStepperRuntoKeepTimeIndex = 20;
    public static final int BeeStepperBoostTimeIndex = 21;
    public static final int BeeIoInIndex = 22;
    public static final int BeeIoOutIndex = 23;
    public static final int BeeEncoderOffsetIndex = 24;
    public static final int BeeEncoderPolarityIndex = 25;
    public static final int BeeEncoderValueIndex = 26;
    public static final int BeeBaudrateIndex = 27;

    public static final int BeeMemoryIndex = 1;//Operation Index

    public static final int BeeFuncReadSDO = 0;
    public static final int BeeFuncWriteSDO = 1;
    public static final int BeeFuncReadSDO_OK = 2;
    public static final int BeeFuncWriteSDO_OK = 3;
    public static final int BeeFuncOperationSDO = 4;
    public static final int BeeFuncOperationSDO_OK = 5;
    public static final int BeeFuncFree = 255;

    public static final int BoardTypeAnt = 0;
    public static final int BoardTypeBee = 1;

    /* Variable for Ant & Bee */
    public static final int txBufferSize = 1000;
    int[] txBufferFuncCode = new int[txBufferSize];
    int[] txBufferID = new int[txBufferSize];
    int[] txBufferSubId = new int[txBufferSize];
    int[] txBufferIndex = new int[txBufferSize];
    int[] txBufferSubIndex = new int[txBufferSize];
    int[] txBufferValue = new int[txBufferSize];
    int txBufferHead = 0;
    int txBufferTail = 0;
    int txBufferLock = 0;

    byte[] usbMsgRxBuf = new byte[512];
    byte[] usbMsgTxBuf = new byte[512];
    public int[][] motorAnt = new int[128][1024];
    public int[][][] motorBee = new int[32][8][32];
    int boardType = 0;
    int[][] targetMonitorFlagBee = new int[32][8];
    int[] targetMonitorFlagAnt = new int[128];

    /* USB system service */
    UsbInterface usbInterfaceFound = null;
    UsbEndpoint endpointIn = null;
    UsbEndpoint endpointOut = null;
    UsbDeviceConnection connection;
    private UsbManager mUsbManager;
    myThread bThread;
    int readyFlag = 0;
    int threadRunFlag = 1;
    monitorThread monitorTask;
    int monitorTaskFlag = 1;

    class myThread extends Thread
    {
        public myThread(String name)
        {
            super(name);
        }

        @Override
        public void run()
        {
            while (threadRunFlag == 1)
            {
                if(boardType == BoardTypeAnt)
                {
                    if(txBufferPopAnt() == 1)
                    {
                        connection.bulkTransfer(endpointOut, usbMsgTxBuf, 10, 500);
                        int ret = connection.bulkTransfer(endpointIn, usbMsgRxBuf, 11, 500);

                        if (ret == 11)
                        {
                            rxBufferAnalysisAnt();
                        }

                    }
                    else
                    {
                        SystemClock.sleep(10);
                    }

                }
                else if(boardType == BoardTypeBee)
                {
                    if(txBufferPopBee()==1)
                    {
                        connection.bulkTransfer(endpointOut, usbMsgTxBuf, 8, 50);
                        int ret = connection.bulkTransfer(endpointIn, usbMsgRxBuf, 8, 500);

                        if (ret == 8)
                        {
                            rxBufferAnalysisBee();
                        }
                    }
                    else
                    {
                        SystemClock.sleep(1);
                    }
                }
            }
            return;
        }
    }

    class monitorThread extends Thread
    {
        public monitorThread(String name)
        {
            super(name);
        }
        @Override
        public void run()
        {
            Log.i("motion", "monitorThread");

            for(int i=1;i<=120;i++)
            {
                targetMonitorFlagAnt[i] = 0;
            }
            for(int i=0;i<32;i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    targetMonitorFlagBee[i][j]=0;
                }
            }
            while(monitorTaskFlag==1)
            {
                if(boardType == BoardTypeAnt)
                {
                    for(int i=1;i<=120;i++)
                    {
                        if(targetMonitorFlagAnt[i] == 1)
                        {
                            txBufferAppendAnt(FUNC_TSDO,i,AntActualPositionIndex,AntReadSubIndex,0);
                            if(motorAnt[i][AntActualPositionIndex] == motorAnt[i][AntStepperRunPosIndex])
                            {
                                targetMonitorFlagAnt[i] = 0;
//                                CallBack.onPosReached(i,0);
                                Log.i("motion", "thread pos reached");
                            }
                        }
                    }
                }
                else if(boardType == BoardTypeBee)
                {
                    for(int i=0;i<32;i++)
                    {
                        for(int j=0;j<8;j++)
                        {
                            if(targetMonitorFlagBee[i][j]==1)
                            {
                                txBufferAppendBee(BeeFuncReadSDO, i, j, BeeActualPositionIndex,0);
                                if(motorBee[i][j][BeeActualPositionIndex] == motorBee[i][j][BeeTargetPositionIndex])
                                {
                                    targetMonitorFlagBee[i][j] = 0;
                                    Log.i("motion", "thread pos reached");
                                }
                            }
                        }
                    }
                }
//                Log.i("motion", "sleep");
                SystemClock.sleep(100);
            }
        }
    }
    /**
     * Broadcast receiver to handle USB disconnect events.
     */
    BroadcastReceiver mUsbReceiver = new BroadcastReceiver()
    {
        public void onReceive(Context context, Intent intent)
        {
            String action = intent.getAction();

            if (UsbManager.ACTION_USB_DEVICE_DETACHED.equals(action))
            {
                UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (device != null)
                {
                    Log.i("usb", "DETACHED my usb");
                    readyFlag = 0;
//                    System.exit(0);
                }
            }
        }
    };
    /**
     * Determine whether to list all devices or query a specific device from
     * the provided intent.
     *
     * @param intent Intent to query.
     */
    @RequiresApi(api = Build.VERSION_CODES.M)
    public void handleIntent(Intent intent, UsbManager mUsbManager, int BoardType)
    {
        boardType = BoardType;

        HashMap<String, UsbDevice> deviceList = mUsbManager.getDeviceList();
        Iterator<UsbDevice> deviceIterator = deviceList.values().iterator();
        while(deviceIterator.hasNext())
        {
            UsbDevice device = deviceIterator.next();
            if(device.getProductId()==29987)
            {
                if(mUsbManager.hasPermission(device))
                {
                    Log.i("usb", "has permission");
                    Log.i("usb", "ATTACHED my usb");
                    Log.i("usb", "PID " + device.getProductId());
                    Log.i("usb", "VID " + device.getVendorId());
                    Log.i("usb", "Interface Count  " + device.getInterfaceCount());
                    Log.i("usb", "Interface Count  " + device.getInterface(0));
                    usbInterfaceFound = device.getInterface(0);

                    endpointIn = usbInterfaceFound.getEndpoint(0);
                    endpointOut = usbInterfaceFound.getEndpoint(1);
                    Log.i("usb", "Endpoint 0 Type: " + endpointIn.getType());
                    Log.i("usb", "Endpoint 0 Direction: " + endpointIn.getDirection());
                    Log.i("usb", "Endpoint 1 Type: " + endpointOut.getType());
                    Log.i("usb", "Endpoint 1 Direction: " + endpointOut.getDirection());

                    connection = mUsbManager.openDevice(device);
                    connection.claimInterface(usbInterfaceFound, true);
                    readyFlag = 1;
                    Log.i("usb", "Ready ");
                    /* UartInit */
                    byte[] var2 = new byte[8];
                    connection.controlTransfer(64, 161, 0, 0, (byte[]) null, 0, 500);
                    if (connection.controlTransfer(192, 95, 0, 0, var2, 2, 500) < 0)
                    {
                        Log.i("usb", "Uart Init False");
                    }
                    else
                    {
                        connection.controlTransfer(64, 154, 4882, 55682, (byte[]) null, 0, 500);
                        connection.controlTransfer(64, 154, 3884, 4, (byte[]) null, 0, 500);
                        if (connection.controlTransfer(192, 149, 9496, 0, var2, 2, 500) < 0)
                        {
                            Log.i("usb", "Uart Init False2");
                        }
                        else
                        {
                            connection.controlTransfer(64, 154, 10023, 0, (byte[]) null, 0, 500);
                            connection.controlTransfer(64, 164, 255, 0, (byte[]) null, 0, 500);
                            Log.i("usb", "Uart Init Success");
                        }
                    }

                    /*SetConfig*/
                    char var10;
                    var10 = 0; // parity none stopbit-1
                    var10 = (char) (var10 | 3); // datatbits-8
                    var10 = (char) (var10 | 192);
                    int var7 = 156 | var10 << 8;

                    int var1 = 1500000;
                    if(boardType == BoardTypeAnt)
                    {
                        /*
                         * factor = 253
                         * divisor = 3*/
                        var1 = 1500000;
                        var1 = (var1 = 0 | 136 | 3) | 252 << 8;//baudrate1500000
                        Log.i("usb", "Board Ant Selected!");
                    }
                    else if(boardType == BoardTypeBee)
                    {
                        /*
                         * factor = 253
                         * divisor = 3*/
                        var1 = 2000000;
                        var1 = (var1 = 0 | 136 | 0x03) | 253 << 8;//baudrate2000000
                        Log.i("usb", "Board Bee Selected!");
                    }
                    /*
                     * VENDOR_SERIAL_INIT = 0xa1 = 161
                     * var7 = value
                     * var1 = index
                     * 	enable SFR_UART RX and TX
                     * reg_value |= 0xc0;
                     * enable SFR_UART Control register and timer
                     * reg_count |= 0x9c;
                     * value |= reg_count;
                     * value |= (unsigned short)reg_value << 8;
                     * index |= 0x80 | divisor;
                     * index |= (unsigned short)factor << 8;
                     */
                    var1 = connection.controlTransfer(64, 161, var7, var1, (byte[]) null, 0, 500);
                    if (var1 >= 0)
                    {
                        Log.i("usb", "SetConfig Init Success");
                    }
                    else
                    {
                        Log.i("usb", "SetConfig Init False");
                    }

                    bThread = new myThread("db-link");
                    threadRunFlag = 1;
                    bThread.start();

                    //            monitorTask = new monitorThread("db-monitor");
                    //            monitorTaskFlag = 1;
                    //            monitorTask.start();
                }
                else
                {
                    Log.i("usb", "has no permission");
                }
            }
        }
    }

    private void txBufferAppendAnt(int FuncCode, int id, int index, int subindex, int value)
    {
        txBufferLock = 1;
        txBufferHead++;
        if (txBufferHead >= txBufferSize)
        {
            txBufferHead = 0;
        }
        txBufferID[txBufferHead] = FuncCode + id;
        txBufferIndex[txBufferHead] = index;
        txBufferSubIndex[txBufferHead] = subindex;
        txBufferValue[txBufferHead] = value;
        txBufferLock = 0;
    }

    private void txBufferAppendBee(int FuncCode, int id, int subid, int index, int value)
    {
        txBufferHead++;
        if (txBufferHead >= txBufferSize)
        {
            txBufferHead = 0;
        }
        txBufferFuncCode[txBufferHead] = FuncCode;
        txBufferID[txBufferHead] = id;
        txBufferSubId[txBufferHead] = subid;
        txBufferIndex[txBufferHead] = index;
        txBufferValue[txBufferHead] = value;
    }

    private int txBufferPopAnt()
    {
        Log.i("motion","Head "+txBufferHead);
        Log.i("motion","Tail "+txBufferTail);
        if(txBufferLock == 1)
        {
            return 0;
        }
        else
        {
            if (txBufferHead != txBufferTail)
            {
                txBufferTail++;
                if (txBufferTail >= txBufferSize)
                {
                    txBufferTail = 0;
                }
                usbMsgTxBuf[0] = (byte) (txBufferID[txBufferTail] & 0xff);
                usbMsgTxBuf[1] = (byte) ((txBufferID[txBufferTail] & 0xff00) >> 8);
                usbMsgTxBuf[2] = (byte) (txBufferIndex[txBufferTail] & 0xff);
                usbMsgTxBuf[3] = (byte) ((txBufferIndex[txBufferTail] & 0xff00) >> 8);
                usbMsgTxBuf[4] = (byte) (txBufferSubIndex[txBufferTail] & 0xff);
                usbMsgTxBuf[5] = (byte) ((txBufferSubIndex[txBufferTail] & 0xff00) >> 8);
                usbMsgTxBuf[6] = (byte) ((txBufferValue[txBufferTail] >> 0) & 0xff);
                usbMsgTxBuf[7] = (byte) ((txBufferValue[txBufferTail] >> 8) & 0xff);
                usbMsgTxBuf[8] = (byte) ((txBufferValue[txBufferTail] >> 16) & 0xff);
                usbMsgTxBuf[9] = (byte) ((txBufferValue[txBufferTail] >> 24) & 0xff);

                return 1;
            }
            else
            {
                usbMsgTxBuf[0] = (byte) (0x80);
                usbMsgTxBuf[1] = (byte) (0x07);
                usbMsgTxBuf[2] = 0;
                usbMsgTxBuf[3] = 0;
                usbMsgTxBuf[4] = 0;
                usbMsgTxBuf[5] = 0;
                usbMsgTxBuf[6] = 0;
                usbMsgTxBuf[7] = 0;
                usbMsgTxBuf[8] = 0;
                usbMsgTxBuf[9] = 0;

                return 0;
            }
        }
    }
    private int txBufferPopBee()
    {
        if (txBufferHead != txBufferTail)
        {
            txBufferTail++;
            if (txBufferTail >= txBufferSize)
            {
                txBufferTail = 0;
            }
            usbMsgTxBuf[0] = (byte) (txBufferFuncCode[txBufferTail] & 0xff);
            usbMsgTxBuf[1] = (byte) (txBufferIndex[txBufferTail] & 0xff);
            usbMsgTxBuf[2] = (byte) (txBufferID[txBufferTail] & 0xff);
            usbMsgTxBuf[3] = (byte) (txBufferSubId[txBufferTail] & 0xff);
            usbMsgTxBuf[4] = (byte) ((txBufferValue[txBufferTail] >> 0) & 0xff);
            usbMsgTxBuf[5] = (byte) ((txBufferValue[txBufferTail] >> 8) & 0xff);
            usbMsgTxBuf[6] = (byte) ((txBufferValue[txBufferTail] >> 16) & 0xff);
            usbMsgTxBuf[7] = (byte) ((txBufferValue[txBufferTail] >> 24) & 0xff);
            return 1;
        }
        else
        {
            return 0;
        }
    }
    private void rxBufferAnalysisAnt()
    {
        int fucnCode = (usbMsgRxBuf[0] & 0x80) + ((usbMsgRxBuf[1] & 0xff) << 8);
        int id = (usbMsgRxBuf[0] & 0x7f);
        int index = (usbMsgRxBuf[2] & 0xff) + ((usbMsgRxBuf[3] & 0xff) << 8);
        int subindex = (usbMsgRxBuf[4] & 0xff) + ((usbMsgRxBuf[5] & 0xff) << 8);
        int value = (usbMsgRxBuf[6] & 0xff) + ((usbMsgRxBuf[7] & 0xff) << 8) + ((usbMsgRxBuf[8] & 0xff) << 16) + ((usbMsgRxBuf[9] & 0xff) << 24);

        motorAnt[id][index] = value;
    }

    private void rxBufferAnalysisBee()
    {
        int fucnCode = usbMsgRxBuf[0] & 0xff;
        int index = (usbMsgRxBuf[1] & 0xff);
        int id = (usbMsgRxBuf[2] & 0xff);
        int subid = (usbMsgRxBuf[3] & 0xff);
        int value = (usbMsgRxBuf[4] & 0xff) + ((usbMsgRxBuf[5] & 0xff) << 8) + ((usbMsgRxBuf[6] & 0xff) << 16) + ((usbMsgRxBuf[7] & 0xff) << 24);

        if(fucnCode == BeeFuncReadSDO_OK)
        {
            motorBee[id][subid][index] = value;
        }
    }

    /*
    * set running current
    * value : 0-1500 for Ant 0-3300 for Bee
    * id : 1 - 120 for Ant, 0-31 for Bee
    * subid: 0 for Ant & Bee, 0-7 for Elephant
    * */
    public void setCurrentRun(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperCurrentRunIndex] != value)
            {
                motorAnt[id][AntStepperCurrentRunIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperCurrentRunIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeStepperCurrentRunIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeStepperCurrentRunIndex, value);
        }
    }

    /*
    * Set Keeping Current, when speed is 0.
    * id : 1 - 120 for Ant, 0-31 for Bee
    * subid: 0 for Ant & Bee, 0-7 for Elephant
    * value : 0-1500 for Ant, 0-3300 for Bee
    * */
    public void setCurrentKeep(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperCurrentKeepIndex] != value)
            {
                motorAnt[id][AntStepperCurrentKeepIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperCurrentKeepIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeStepperCurrentKeepIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeStepperCurrentKeepIndex, value);
        }
    }

    /*
    * Set Speed
    * In Profile Position Mode, Speed is a positive number, range from 0 to 2000(according to motor's performace)
    * In Profile Velocity Mode, Speed has directions, + or - means two diretions.
    *  */
    public void setSpeed(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperRunVelIndex] != value)
            {
                motorAnt[id][AntStepperRunVelIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperRunVelIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeTargetVelocityIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeTargetVelocityIndex, value);
        }
    }

    /*
    * set the Acc and Dec time
    * unit: ms
    * range: value > 0, 200ms to 2000ms performs better
    * */
    public void setAccTime(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperAccTimeIndex] != value)
            {
                motorAnt[id][AntStepperAccTimeIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperAccTimeIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeProfileAccTimeIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeProfileAccTimeIndex, value);
        }
    }

    /*
    * Set Operation Mode:
    * */
    public void setOpMode(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntModesofOperationIndex] != value)
            {
                motorAnt[id][AntModesofOperationIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntModesofOperationIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeOperationModeIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeOperationModeIndex, value);
        }
    }
    /*
    * Enter Homing Mode
    * */
    public void setOpModeHoming(int id, int subid)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntModesofOperationIndex] != OPMODE_HOMING)
            {
                motorAnt[id][AntModesofOperationIndex] = OPMODE_HOMING;
                txBufferAppendAnt(FUNC_TSDO, id, AntModesofOperationIndex, AntWriteSubIndex, OPMODE_HOMING);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeOperationModeIndex] = OPMODE_HOMING;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeOperationModeIndex, OPMODE_HOMING);
        }
    }
    /*
     * Enter Profile Positon Mode
     * */
    public void setOpModeProfilePositon(int id, int subid)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntModesofOperationIndex] != OPMODE_PROFILE_POSITION)
            {
                motorAnt[id][AntModesofOperationIndex] = OPMODE_PROFILE_POSITION;
                txBufferAppendAnt(FUNC_TSDO, id, AntModesofOperationIndex, AntWriteSubIndex, OPMODE_PROFILE_POSITION);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeOperationModeIndex] = OPMODE_PROFILE_POSITION;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeOperationModeIndex, OPMODE_PROFILE_POSITION);
        }
    }

    /*
    * Set Homing Direction for Homing Mode
    * value can be 1 or -1
    * */
    public void setHomingDir(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperHomeDirIndex] != value)
            {
                motorAnt[id][AntStepperHomeDirIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperHomeDirIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeHomingDirIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeHomingDirIndex, value);
        }
    }
    public void setHomingDirPositive(int id, int subid)
    {
        int value = 1;
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperHomeDirIndex] != value)
            {
                motorAnt[id][AntStepperHomeDirIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperHomeDirIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeHomingDirIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeHomingDirIndex, value);
        }
    }
    public void setHomingDirNegative(int id, int subid)
    {
        int value = -1;
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperHomeDirIndex] != value)
            {
                motorAnt[id][AntStepperHomeDirIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperHomeDirIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeHomingDirIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeHomingDirIndex, value);
        }
    }

    /*
    * Set Homing Sensor trigger Level
    * value can be 0 or 1
    * */
    public void setHomingLevel(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperHomeLevelIndex] != value)
            {
                motorAnt[id][AntStepperHomeLevelIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperHomeLevelIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeHomingLevelIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeHomingLevelIndex, value);
        }
    }
    public void setHomingLevelHigh(int id, int subid)
    {
        int value = 1;
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperHomeLevelIndex] != value)
            {
                motorAnt[id][AntStepperHomeLevelIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperHomeLevelIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeHomingLevelIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeHomingLevelIndex, value);
        }
    }
    public void setHomingLevelLow(int id, int subid)
    {
        int value = 0;
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntStepperHomeLevelIndex] != value)
            {
                motorAnt[id][AntStepperHomeLevelIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntStepperHomeLevelIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeHomingLevelIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeHomingLevelIndex, value);
        }
    }
    /*
    * set Enable
    * value can 0 or 1
    * 0- disable
    * 1- enable
    * */
    public void setEnable(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            if (motorAnt[id][AntControlWordIndex] != value)
            {
                motorAnt[id][AntControlWordIndex] = value;
                txBufferAppendAnt(FUNC_TSDO, id, AntControlWordIndex, AntWriteSubIndex, value);
            }
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeControlWordIndex] = value;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeControlWordIndex, value);
        }
    }

    /*
    * Save Parameters to Board Flash Memory
    * */
    public void saveParameters(int id, int subid)
    {
        if (boardType == BoardTypeAnt)
        {
            txBufferAppendAnt(FUNC_TSDO, id, AntMemoryIndex, AntWriteSubIndex, 1);
        }
        else if(boardType == BoardTypeBee)
        {
            txBufferAppendBee(BeeFuncOperationSDO, id, subid, BeeMemoryIndex, 1);
        }
    }

    public void setPos(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            motorAnt[id][AntStepperRunPosIndex] = value;
            targetMonitorFlagAnt[id] = 1;
            txBufferAppendAnt(FUNC_TSDO, id, AntStepperRunPosIndex, AntWriteSubIndex, value);
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeTargetPositionIndex] = value;
            targetMonitorFlagBee[id][subid] = 1;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeTargetPositionIndex, value);
        }
    }

    public int getPos(int id, int subid)
    {
        if (boardType == BoardTypeAnt)
        {
            txBufferAppendAnt(FUNC_TSDO, id, AntStepperRunPosIndex, AntReadSubIndex, 0);
            return motorAnt[id][AntActualPositionIndex];
        }
        else if(boardType == BoardTypeBee)
        {
            txBufferAppendBee(BeeFuncReadSDO, id, subid, BeeTargetPositionIndex, 0);
            return motorBee[id][subid][BeeActualPositionIndex];
        }
        return 0;
    }

    public int waitPos(int id, int subid)
    {
        if (boardType == BoardTypeAnt)
        {
            txBufferAppendAnt(FUNC_TSDO, id, AntActualPositionIndex, AntReadSubIndex, 0);

            if (motorAnt[id][AntActualPositionIndex]  == motorAnt[id][AntStepperRunPosIndex])
            {
                return 1;
            }
            else
            {
                txBufferAppendAnt(FUNC_TSDO, id, AntActualPositionIndex, AntReadSubIndex, 0);
                return 0;
            }
        }
        else if(boardType == BoardTypeBee)
        {
            if(motorBee[id][subid][BeeActualPositionIndex] == motorBee[id][subid][BeeTargetPositionIndex])
            {
                return 1;
            }
            else
            {
//                txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeTargetPositionIndex, motorBee[id][subid][BeeTargetPositionIndex]);
                txBufferAppendBee(BeeFuncReadSDO, id, subid, BeeActualPositionIndex, 0);
                return 0;
            }
        }
        return -1;
    }

    public void setVel(int id, int subid, int value)
    {
        if (boardType == BoardTypeAnt)
        {
            motorAnt[id][AntStepperRunVelIndex] = value;
            targetMonitorFlagAnt[id] = 1;
            txBufferAppendAnt(FUNC_TSDO, id, AntStepperRunVelIndex, AntWriteSubIndex, value);
        }
        else if(boardType == BoardTypeBee)
        {
            motorBee[id][subid][BeeTargetVelocityIndex] = value;
            targetMonitorFlagBee[id][subid] = 1;
            txBufferAppendBee(BeeFuncWriteSDO, id, subid, BeeTargetVelocityIndex, value);
        }
    }

}
