function DBD_setPowerOn(id)
%DBD_POWERON PowerOn the Device
%   id: the device id you want to power on
global DBD;
DBD_SendMessage(DBD.FUNC_CODE_TSDO, id, DBD.INDEX_CONTROL_WORD, DBD.SUBINDEX_WRITE, 1);
end

