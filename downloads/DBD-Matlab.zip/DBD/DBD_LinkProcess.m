function DBD_LinkProcess()
global DBD;
if(DBD.txQueue.head ~= DBD.txQueue.tail)
    % pop up txData from queue
    DBD.txQueue.tail = DBD.txQueue.tail +1;
    if(DBD.txQueue.tail > DBD.txQueue.length)
        DBD.txQueue.tail = 1;
    end
    id = typecast(DBD.txQueue.id(DBD.txQueue.tail),'uint8');
    index = typecast(DBD.txQueue.index(DBD.txQueue.tail),'uint8');
    subindex = typecast(DBD.txQueue.subindex(DBD.txQueue.tail),'uint8');
    data = typecast(DBD.txQueue.data(DBD.txQueue.tail),'uint8');

    % pack txData to txBuffer
    DBD.txBuf(1) = id(1);
    DBD.txBuf(2) = id(2);
    DBD.txBuf(3) = index(1);
    DBD.txBuf(4) = index(2);
    DBD.txBuf(5) = subindex(1);
    DBD.txBuf(6) = subindex(2);
    DBD.txBuf(7) = data(1);
    DBD.txBuf(8) = data(2);
    DBD.txBuf(9) = data(3);
    DBD.txBuf(10) = data(4);

    % Send over Serial Port
    fwrite(DBD.serialport,DBD.txBuf);

    
    % Receive Rx Data
    pause(0.05)
    num = get(DBD.serialport,'BytesAvailable');
    if(num>0)
        DBD.rxBuf = fread(DBD.serialport,get(DBD.serialport,'BytesAvailable'),'uint8');
        [a,b] = size(DBD.rxBuf);
        if a == 11
            % Analysis Rx Data
            rxID = typecast(uint8([DBD.rxBuf(1) DBD.rxBuf(2)]),'uint16');
            rxIndex = typecast(uint8([DBD.rxBuf(3) DBD.rxBuf(4)]),'uint16');
            rxSubindex = typecast(uint8([DBD.rxBuf(5) DBD.rxBuf(6)]),'uint16');
            rxData = typecast(uint8([DBD.rxBuf(7) DBD.rxBuf(8) DBD.rxBuf(9) DBD.rxBuf(10)]),'int32');
            rxFuncCode = bitand(rxID,hex2dec('ff80'));
            rxDeviceID = bitand(rxID,hex2dec('007f'));

            if rxFuncCode ~= hex2dec('780')
                % Note: Matlab�������1��ʼ, ��C/Python�������0��ʼ
                % �����������ƫ��: ��motors(1,1)������ŵ�0������ĵ�0��������Ӧ�Ĳ���
                if(rxDeviceID >= 0)
                    if(rxDeviceID <=120)
                        if(rxIndex >=0)
                            if(rxIndex <=1020)
                                DBD.motors(rxDeviceID+1,rxIndex+1) = rxData;
                            end
                        end
                    end
                end
            end
        end
    end
end
end