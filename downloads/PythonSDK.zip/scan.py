from DBDynamicsPro import Ant
import time
m = Ant('/dev/ttyUSB0')  # or COM2 COM3
m.scanDevices()
# print(m.getDeviceID(1))
# time.sleep(1)
# print(m.getDeviceID(1))
# time.sleep(1)
# print(m.getDeviceID(1))
# time.sleep(1)
m.stop()