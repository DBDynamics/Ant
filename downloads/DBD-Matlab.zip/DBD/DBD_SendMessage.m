function DBD_SendMessage(func_code, device_id, index, subindex, data)
global DBD;    
id = func_code + device_id;
DBD.txQueue.head = DBD.txQueue.head + 1;
if(DBD.txQueue.head > DBD.txQueue.length)
    DBD.txQueue.head = 1;
end
DBD.txQueue.id(DBD.txQueue.head) = id;
DBD.txQueue.index(DBD.txQueue.head) = index;
DBD.txQueue.subindex(DBD.txQueue.head) = subindex;
DBD.txQueue.data(DBD.txQueue.head) = data;
end

