function DBD = DBD_Init(portName)
% Constant Variables for Communication Profiles(Do not Change it!!)
% DBD = DBD_Init(portName)
global DBD;
DBD.FUNC_CODE_TSDO = hex2dec('0580');
DBD.FUNC_CODE_FREE = hex2dec('0780');
DBD.FUNC_CODE_SYNC = hex2dec('0080');
DBD.STATUS_WORD_DEVICE_ENABLED = hex2dec('01');
DBD.STATUS_WORD_HOME_FIND = hex2dec('02');
DBD.STATUS_WORD_TARGET_REACHED = hex2dec('04');
DBD.STATUS_WORD_IO_INPUT = hex2dec('08');
DBD.OPERATION_MODE_PROFILE_VELOCITY = 21;
DBD.OPERATION_MODE_PROFILE_POSITION = 31;
DBD.OPERATION_MODE_HOMING = 40;
DBD.SUBINDEX_WRITE = 0;
DBD.SUBINDEX_READ = 1;
DBD.INDEX_CONTROL_WORD = 0;
DBD.INDEX_OPERATION_MODE = 1;
DBD.INDEX_IO_OUT = 14;
DBD.INDEX_MEMORY = 30;
DBD.INDEX_DEVICE_ID = 31;
DBD.INDEX_RUNNING_CURRENT = 40;
DBD.INDEX_KEEPING_CURRENT = 42;
DBD.INDEX_HOMING_DIR = 45;
DBD.INDEX_HOMING_LEVEL = 46;
DBD.INDEX_ACC_TIME = 47;
DBD.INDEX_TARGET_VELOCITY = 48;
DBD.INDEX_TARGET_POSITION = 49;
DBD.INDEX_STATUS_WORD = 50;
DBD.INDEX_ACTUAL_VELOCITY = 52;
DBD.INDEX_ACTUAL_POSITION = 53;
DBD.INDEX_IO_INPUT = 54;

% Parameter Variables
DBD.motors = zeros(128,1024,'int32');% 120 motors, each motor has 1024 parameters

% Tx Queue
DBD.txQueue = [];
DBD.txQueue.length = 100;
DBD.txQueue.head = 1;
DBD.txQueue.tail = 1;
DBD.txQueue.id = zeros(1,100,'uint16');
DBD.txQueue.index = zeros(1,100,'uint16');
DBD.txQueue.subindex = zeros(1,100,'uint16');
DBD.txQueue.data = zeros(1,100,'int32');
DBD.txBuf = zeros(1,10);
DBD.rxBuf = zeros(1,11);


% Communication Setup
delete(instrfind);
delete(instrfindall);
pause(0.1);    
DBD.serialport = serial(portName);   
set(DBD.serialport,'BaudRate',1500000,'DataBits', 8, 'Parity', 'none','StopBits', 1, 'FlowControl', 'none','Terminator','CR/LF');
set(DBD.serialport,'InputBufferSize', 11)
set(DBD.serialport, 'OutputBufferSize', 10);
set(DBD.serialport, 'Timeout', 0.01);
% set(DBD.serialport, 'ReadAsyncMode', 'manual');
fopen(DBD.serialport);
if DBD.serialport.Status == 'open'
    disp("COM Port Open Successfully");
else
    disp("COM Port Open Failed");
    exit;
end

% Timer
DBD.timerCounter = 0;
DBD.timer = timer;
DBD.timer.Period= 0.02;
DBD.timer.TimerFcn = @DBD_TimerFunc;
DBD.timer.ExecutionMode='fixedRate';
DBD.timer.StartDelay = 0.5;
DBD.timer.start;

pause(0.5)
disp('DBD Communication Process is Running Background, Run DBD_Stop() to Stop it');


end

