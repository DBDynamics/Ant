package com.example.dbdriver;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.telecom.Call;
import android.util.EventLog;
import android.util.Log;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;

public class DBDActivity extends AppCompatActivity
{
    private static final String TAG = "UsbEnumerator";
    public static final int FUNC_TSDO = 0X580;
    public static final int AntControlWordIndex = 0;
    public static final int AntModesofOperationIndex = 1;
    public static final int AntIO_OUT_Index = 14;
    public static final int AntMemoryIndex = 30;
    public static final int AntDeviceIDIndex = 31;
    public static final int AntHeartBeatRateIndex = 35;
    public static final int AntStepperCurrentRunIndex = 40;
    public static final int AntStepperCurrentKeepIndex = 42;
    public static final int AntStepperRunVelIndex = 48;
    public static final int AntStepperAccTimeIndex = 47;
    public static final int AntStepperHomeDirIndex = 45;
    public static final int AntStepperHomeLevelIndex = 46;
    public static final int AntStepperRunPosIndex = 49;
    public static final int AntStatusWordIndex = 50;
    public static final int AntActualVelocityIndex = 52;
    public static final int AntActualPositionIndex = 53;
    public static final int AntIO_InputIndex = 54;
    public static final int AntWriteSubIndex = 0;
    public static final int AntReadSubIndex = 1;
    public static final int AntWriteOKSubIndex = 2;
    public static final int AntReadOKSubIndex = 3;
    public static final int STATUS_DEVICE_ENABLED = 0x01;
    public static final int STATUS_TARGET_REACHED = 0x04;
    public static final int STATUS_IO_INPUT = 0x08;
    public static final int STATUS_IO_INPUT2 = 0x10;
    public static final int OPMODE_PROFILE_POSITION = 31;
    public static final int OPMODE_PROFILE_VELOCITY = 21;
    public static final int OPMODE_PROFILE_POSITION_SYNC = 33;
    public static final int OPMODE_PROFILE_VELOCITY_SYNC = 23;
    public static final int OPMODE_POSITION_ENCODER = 35;
    public static final int OPMODE_SENSOR_FLIP = 36;
    public static final int OPMODE_HOMING = 40;

    /* Profile for Stepper Bee */
    public static final int BeeBoardTypeIndex = 0;
    public static final int BeeDeviceIDIndex = 1;
    public static final int BeeControlWordIndex = 2;
    public static final int BeeOperationModeIndex = 3;
    public static final int BeeStatusWordIndex = 4;
    public static final int BeeTargetCurrentIndex = 5;
    public static final int BeeActualCurrentIndex = 6;
    public static final int BeeTargetVelocityIndex = 7;
    public static final int BeeActualVelocityIndex = 8;
    public static final int BeeTargetPositionIndex = 9;
    public static final int BeeActualPositionIndex = 10;
    public static final int BeeProfileAccTimeIndex = 11;
    public static final int BeeInterpolationTargetPostionIndex = 12;
    public static final int BeeHomingModeIndex = 13;
    public static final int BeeHomingDirIndex = 14;
    public static final int BeeHomingLevelIndex = 15;
    public static final int BeeHomingOffsetIndex = 16;
    public static final int BeeStepperCurrentRunIndex = 17;
    public static final int BeeStepperCurrentKeepIndex = 18;
    public static final int BeeStepperCurrentBoostIndex = 19;
    public static final int BeeStepperRuntoKeepTimeIndex = 20;
    public static final int BeeStepperBoostTimeIndex = 21;
    public static final int BeeIoInIndex = 22;
    public static final int BeeIoOutIndex = 23;
    public static final int BeeEncoderOffsetIndex = 24;
    public static final int BeeEncoderPolarityIndex = 25;
    public static final int BeeEncoderValueIndex = 26;
    public static final int BeeBaudrateIndex = 27;

    public static final int BeeMemoryIndex = 1;//Operation Index

    public static final int BeeFuncReadSDO = 0;
    public static final int BeeFuncWriteSDO = 1;
    public static final int BeeFuncReadSDO_OK = 2;
    public static final int BeeFuncWriteSDO_OK = 3;
    public static final int BeeFuncOperationSDO = 4;
    public static final int BeeFuncOperationSDO_OK = 5;
    public static final int BeeFuncFree = 255;

    public static final int BoardTypeAnt = 0;
    public static final int BoardTypeBee = 1;


    /* Profile for Bee Temperature Control Board */
    public static final int BeeTempBoardTypeIndex = 0;
    public static final int BeeTempDeviceIDIndex = 1;
    public static final int BeeTempControlWordIndex = 2;
    public static final int BeeTempTargetTempIndex = 9;
    public static final int BeeTempActualTempIndex = 10;
    public static final int BeeTempTempOffsetIndex = 11;
    public static final int BeeTempFanTempIndex = 22;
    public static final int BeeTempOutIndex = 23;

    /* Variable for Ant & Bee */
    public static final int txBufferSize = 1000;
    public static final int usbChannelSize = 4;
    int[][] txBufferFuncCode = new int[usbChannelSize][txBufferSize];
    int[][] txBufferID = new int[usbChannelSize][txBufferSize];
    int[][] txBufferSubId = new int[usbChannelSize][txBufferSize];
    int[][] txBufferIndex = new int[usbChannelSize][txBufferSize];
    int[][] txBufferSubIndex = new int[usbChannelSize][txBufferSize];
    int[][] txBufferValue = new int[usbChannelSize][txBufferSize];
    int[] txBufferHead = new int[usbChannelSize];
    int[] txBufferTail = new int[usbChannelSize];
    int[] txBufferLock = new int[usbChannelSize];

    /* USB RTX BUF 4 CHANNEL */
    byte[][] usbMsgRxBuf = new byte[usbChannelSize][512];
    byte[][] usbMsgTxBuf = new byte[usbChannelSize][512];

    /* Motor Data for 4 CHANNEL */
    public int[][][] motorAnt = new int[usbChannelSize][128][1024];
    public int[][][][] motorBee = new int[usbChannelSize][32][8][32];
    int boardType = 0;
    int[][][] targetMonitorFlagBee = new int[usbChannelSize][32][8];
    int[][][] targetReachedFlagBee = new int[usbChannelSize][32][8];
    int[][] targetMonitorFlagAnt = new int[usbChannelSize][128];
    int[][] targetReachedFlagAnt = new int[usbChannelSize][128];
    int targetMonitorCounter = 0;

    /* USB system service */
    private static final String ACTION_USB_PERMISSION = "com.android.usb.USB_PERMISSION";
    UsbInterface[] usbInterfaceFound = new UsbInterface[usbChannelSize];
    UsbEndpoint[] endpointIn = new UsbEndpoint[usbChannelSize];
    UsbEndpoint[] endpointOut = new UsbEndpoint[usbChannelSize];
    UsbDeviceConnection[] connection = new UsbDeviceConnection[usbChannelSize];
    UsbDevice[] device = new UsbDevice[usbChannelSize];
    PendingIntent permissionIntent;
    int usbPermissionReadyFlag = 0;
    int connectedDevices = 0;
    int connectedCANDevices = 0;
    int connectedRS485Devices = 0;
    int[] connectionType = new int[usbChannelSize];
    public static final int _CONNECTION_TYPE_NONE = 0;
    public static final int _CONNECTION_TYPE_CAN = 1;
    public static final int _CONNECTION_TYPE_RS485 = 2;

    myThread bThread;
    int readyFlag = 0;
    int threadRunFlag = 0;
    int monitorTaskFlag = 1;

    public DBDMotorCallback EventCallback;

    class myThread extends Thread
    {
        UsbManager usbManager;

        public myThread(UsbManager usbManager)
        {
            this.usbManager = usbManager;
        }

        @Override
        public void run()
        {
            /* Step1: scan USB & check Permission */
            HashMap<String, UsbDevice> deviceList = usbManager.getDeviceList();
            if (!(deviceList.isEmpty()))
            {
                connectedDevices = 0;
                for (UsbDevice usbDevice : deviceList.values())
                {
                    int VendorID = usbDevice.getVendorId();
                    int ProductID = usbDevice.getProductId();

                    // 保存匹配到的设备
                    if (VendorID == 6790 && ProductID == 29987)
                    {
                        device[connectedDevices] = usbDevice;
                        usbPermissionReadyFlag = 0;
                        if (!usbManager.hasPermission(device[connectedDevices]))
                        {
                            usbManager.requestPermission(usbDevice, permissionIntent);
                            Log.i("usb", connectedDevices + "Need USB Permission ");
                        }
                        else
                        {
                            usbPermissionReadyFlag = 1;
                        }
                        while (usbPermissionReadyFlag == 0)
                        {
                            SystemClock.sleep(100);
                        }

                        Log.i("usb", connectedDevices + "USB Found ");
                        connectedDevices++;
                    }
                }
            }
            /* Step2: Check Communication Type: CAN or RS485 */
            for (int i = 0; i < connectedDevices; i++)
            {
                usbInterfaceFound[i] = device[i].getInterface(0);
                endpointIn[i] = usbInterfaceFound[i].getEndpoint(0);
                endpointOut[i] = usbInterfaceFound[i].getEndpoint(1);
                connection[i] = usbManager.openDevice(device[i]);
                connection[i].claimInterface(usbInterfaceFound[i], true);

                /* Try to Test CAN */
                /* For CAN Bus Devices, should power on first, otherwise cannot identify */
                configureCH340(connection[i], _CONNECTION_TYPE_CAN);
                connection[i].bulkTransfer(endpointOut[i], usbMsgTxBuf[i], 10, 100);
                int ret = connection[i].bulkTransfer(endpointIn[i], usbMsgRxBuf[i], 11, 100);

                if (ret == 11)
                {
                    connectionType[i] = _CONNECTION_TYPE_CAN;
                    connectedRS485Devices++;
                    Log.i("usb", i + "USB CAN ");
                }
                else
                {
                    configureCH340(connection[i], _CONNECTION_TYPE_RS485);
                    connection[i].bulkTransfer(endpointOut[i], usbMsgTxBuf[i], 8, 100);
                    ret = connection[i].bulkTransfer(endpointIn[i], usbMsgRxBuf[i], 8, 100);

                    if (ret == 8)
                    {
                        connectionType[i] = _CONNECTION_TYPE_RS485;
                        connectedCANDevices++;
                        Log.i("usb", i + "USB RS485 ");
                    }
                    else
                    {
                        connectionType[i] = _CONNECTION_TYPE_NONE;
                        Log.i("usb", i + "USB NONE ");
                    }
                }
            }

            /* Step3: start communication progress */
            /* Now support 4 channel usb communication
             * need 4 channel communication buffer: msg queue, usb buf
             * Communication in parallel
             * If txQueue has msg, then send it*/
            threadRunFlag = 1;
            int counter = 0;
            int[] sendStatus= new int[4];
            Log.i("usb", "usb ready");
            while (threadRunFlag == 1)
            {
                counter++;
                for (int i = 0; i < connectedDevices; i++)
                {
                    sendStatus[i] = 0;
                }
//                Log.i("usb",  "usb send conuter:"+counter);
                /* Send USB msg */
                for (int i = 0; i < connectedDevices; i++)
                {
                    if (connectionType[i] == _CONNECTION_TYPE_CAN)
                    {
                        if (txBufferPopCAN(i) == 1)
                        {
                            sendStatus[i] = connection[i].bulkTransfer(endpointOut[i], usbMsgTxBuf[i], 10, 100);
//                            Log.i("usb",  "txBufferPopSend"+i);
                        }
                    }
                    if (connectionType[i] == _CONNECTION_TYPE_RS485)
                    {
                        if (txBufferPopRS485(i) == 1)
                        {
                            sendStatus[i] = connection[i].bulkTransfer(endpointOut[i], usbMsgTxBuf[i], 8, 100);
//                            Log.i("usb",  " rs485 txBufferPopSend"+i);
                        }
                    }
                }
                /* Receive USB msg */
                for (int i = 0; i < connectedDevices; i++)
                {
                    if(sendStatus[i]>0)
                    {
                        if (connectionType[i] == _CONNECTION_TYPE_CAN)
                        {
                            int ret = connection[i].bulkTransfer(endpointIn[i], usbMsgRxBuf[i], 11, 100);

                            if (ret == 11)
                            {
                                rxBufferAnalysisCAN(i);
                            }

                        }
                        else if (connectionType[i] == _CONNECTION_TYPE_RS485)
                        {
                            int ret = connection[i].bulkTransfer(endpointIn[i], usbMsgRxBuf[i], 8, 100);

                            if (ret == 8)
                            {
                                rxBufferAnalysisRS485(i);
                            }
                        }
                    }
                }
            }
            Log.i("usb", "End of db-link ");
        }
    }

    public void scanUSB(Context context, UsbManager mUsbManager)
    {
        permissionIntent = PendingIntent.getBroadcast(context, 0, new Intent(ACTION_USB_PERMISSION), 0);
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        context.registerReceiver(usbReceiver, filter);
        bThread = new myThread(mUsbManager);
        bThread.start();
    }

    private final BroadcastReceiver usbReceiver = new BroadcastReceiver()
    {
        public void onReceive(Context context, Intent intent)
        {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action))
            {
                synchronized (this)
                {
                    UsbDevice device = (UsbDevice) intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false))
                    {
                        if (device != null)
                        {
                            Log.d("usb", "permission passed for device " + device);
                            usbPermissionReadyFlag = 1;
                        }
                    }
                    else
                    {
                        Log.d("usb", "permission denied for device " + device);
                    }
                }
            }
        }
    };

    private void configureCH340(UsbDeviceConnection connection, int type)
    {
        /* UartInit */
        byte[] var2 = new byte[8];
        connection.controlTransfer(64, 161, 0, 0, (byte[]) null, 0, 500);
        if (connection.controlTransfer(192, 95, 0, 0, var2, 2, 500) < 0)
        {
            Log.i("usb", "Uart Init False");
        }
        else
        {
            connection.controlTransfer(64, 154, 4882, 55682, (byte[]) null, 0, 500);
            connection.controlTransfer(64, 154, 3884, 4, (byte[]) null, 0, 500);
            if (connection.controlTransfer(192, 149, 9496, 0, var2, 2, 500) < 0)
            {
                Log.i("usb", "Uart Init False2");
            }
            else
            {
                connection.controlTransfer(64, 154, 10023, 0, (byte[]) null, 0, 500);
                connection.controlTransfer(64, 164, 255, 0, (byte[]) null, 0, 500);
                Log.i("usb", "Uart Init Success");
            }
        }

        /*SetConfig*/
        char var10;
        var10 = 0; // parity none stopbit-1
        var10 = (char) (var10 | 3); // datatbits-8
        var10 = (char) (var10 | 192);
        int var7 = 156 | var10 << 8;

        int var1 = 1500000;
        if (type == _CONNECTION_TYPE_CAN)
        {
            /*
             * factor = 253
             * divisor = 3*/
            var1 = 1500000;
            var1 = (var1 = 0 | 136 | 3) | 252 << 8;//baudrate1500000
            Log.i("usb", "Board Ant Selected!");
        }
        else if (type == _CONNECTION_TYPE_RS485)
        {
            /*
             * factor = 253
             * divisor = 3*/
            var1 = 2000000;
            var1 = (var1 = 0 | 136 | 0x03) | 253 << 8;//baudrate2000000
            Log.i("usb", "Board Bee Selected!");
        }
        /*
         * VENDOR_SERIAL_INIT = 0xa1 = 161
         * var7 = value
         * var1 = index
         * 	enable SFR_UART RX and TX
         * reg_value |= 0xc0;
         * enable SFR_UART Control register and timer
         * reg_count |= 0x9c;
         * value |= reg_count;
         * value |= (unsigned short)reg_value << 8;
         * index |= 0x80 | divisor;
         * index |= (unsigned short)factor << 8;
         */
        var1 = connection.controlTransfer(64, 161, var7, var1, (byte[]) null, 0, 500);
        if (var1 >= 0)
        {
            Log.i("usb", "SetConfig Init Success");
        }
        else
        {
            Log.i("usb", "SetConfig Init False");
        }
    }

    private void txBufferAppendCAN(int channel, int FuncCode, int id, int index, int subindex, int value)
    {
        txBufferLock[channel] = 1;
        txBufferHead[channel]++;
        if (txBufferHead[channel] >= txBufferSize)
        {
            txBufferHead[channel] = 0;
        }

            txBufferID[channel][txBufferHead[channel]] = FuncCode + id;
            txBufferIndex[channel][txBufferHead[channel]] = index;
            txBufferSubIndex[channel][txBufferHead[channel]] = subindex;
            txBufferValue[channel][txBufferHead[channel]] = value;


        txBufferLock[channel] = 0;
    }
    private void txBufferAppendRS485(int channel, int FuncCode, int id, int subid, int index, int value)
    {
        txBufferLock[channel] = 1;
        txBufferHead[channel]++;
        if (txBufferHead[channel] >= txBufferSize)
        {
            txBufferHead[channel] = 0;
        }
        txBufferFuncCode[channel][txBufferHead[channel]] = FuncCode;
        txBufferID[channel][txBufferHead[channel]] = id;
        txBufferIndex[channel][txBufferHead[channel]] = index;
        txBufferSubId[channel][txBufferHead[channel]] = subid;
        txBufferValue[channel][txBufferHead[channel]] = value;
    }

    private int txBufferPopCAN(int channel)
    {
//        Log.i("usb", "Channel:"+channel);
//        Log.i("usb", "txBufferHead"+txBufferHead[channel]);
//        Log.i("usb", "txBufferTail"+txBufferTail[channel]);
        if (txBufferLock[channel] == 1)
        {
            return 0;
        }
        else
        {
            if (txBufferHead[channel] != txBufferTail[channel])
            {
                txBufferTail[channel]++;
                if (txBufferTail[channel] >= txBufferSize)
                {
                    txBufferTail[channel] = 0;
                }
                usbMsgTxBuf[channel][0] = (byte) (txBufferID[channel][txBufferTail[channel]] & 0xff);
                usbMsgTxBuf[channel][1] = (byte) ((txBufferID[channel][txBufferTail[channel]] & 0xff00) >> 8);
                usbMsgTxBuf[channel][2] = (byte) (txBufferIndex[channel][txBufferTail[channel]] & 0xff);
                usbMsgTxBuf[channel][3] = (byte) ((txBufferIndex[channel][txBufferTail[channel]] & 0xff00) >> 8);
                usbMsgTxBuf[channel][4] = (byte) (txBufferSubIndex[channel][txBufferTail[channel]] & 0xff);
                usbMsgTxBuf[channel][5] = (byte) ((txBufferSubIndex[channel][txBufferTail[channel]] & 0xff00) >> 8);
                usbMsgTxBuf[channel][6] = (byte) ((txBufferValue[channel][txBufferTail[channel]] >> 0) & 0xff);
                usbMsgTxBuf[channel][7] = (byte) ((txBufferValue[channel][txBufferTail[channel]] >> 8) & 0xff);
                usbMsgTxBuf[channel][8] = (byte) ((txBufferValue[channel][txBufferTail[channel]] >> 16) & 0xff);
                usbMsgTxBuf[channel][9] = (byte) ((txBufferValue[channel][txBufferTail[channel]] >> 24) & 0xff);

                return 1;
            }
//            else
//            {
//                usbMsgTxBuf[channel][0] = (byte) (0x80);
//                usbMsgTxBuf[channel][1] = (byte) (0x07);
//                usbMsgTxBuf[channel][2] = 0;
//                usbMsgTxBuf[channel][3] = 0;
//                usbMsgTxBuf[channel][4] = 0;
//                usbMsgTxBuf[channel][5] = 0;
//                usbMsgTxBuf[channel][6] = 0;
//                usbMsgTxBuf[channel][7] = 0;
//                usbMsgTxBuf[channel][8] = 0;
//                usbMsgTxBuf[channel][9] = 0;
//
//                return 1;
//            }
            else
            {
                return 0;
            }
        }
    }

    private int txBufferPopRS485(int channel)
    {
//        Log.i("usb", "Channel:"+channel);
//        Log.i("usb", "txBufferHead"+txBufferHead[channel]);
//        Log.i("usb", "txBufferTail"+txBufferTail[channel]);
        if (txBufferHead[channel] != txBufferTail[channel])
        {
            txBufferTail[channel]++;
            if (txBufferTail[channel] >= txBufferSize)
            {
                txBufferTail[channel] = 0;
            }
            usbMsgTxBuf[channel][0] = (byte) (txBufferFuncCode[channel][txBufferTail[channel]] & 0xff);
            usbMsgTxBuf[channel][1] = (byte) (txBufferIndex[channel][txBufferTail[channel]] & 0xff);
            usbMsgTxBuf[channel][2] = (byte) (txBufferID[channel][txBufferTail[channel]] & 0xff);
            usbMsgTxBuf[channel][3] = (byte) (txBufferSubId[channel][txBufferTail[channel]] & 0xff);
            usbMsgTxBuf[channel][4] = (byte) ((txBufferValue[channel][txBufferTail[channel]] >> 0) & 0xff);
            usbMsgTxBuf[channel][5] = (byte) ((txBufferValue[channel][txBufferTail[channel]] >> 8) & 0xff);
            usbMsgTxBuf[channel][6] = (byte) ((txBufferValue[channel][txBufferTail[channel]] >> 16) & 0xff);
            usbMsgTxBuf[channel][7] = (byte) ((txBufferValue[channel][txBufferTail[channel]] >> 24) & 0xff);
            return 1;
        }
        else
        {
            return 0;
        }
    }

    private void rxBufferAnalysisCAN(int channel)
    {
        int fucnCode = (usbMsgRxBuf[channel][0] & 0x80) + ((usbMsgRxBuf[channel][1] & 0xff) << 8);
        int id = (usbMsgRxBuf[channel][0] & 0x7f);
        int index = (usbMsgRxBuf[channel][2] & 0xff) + ((usbMsgRxBuf[channel][3] & 0xff) << 8);
        int subindex = (usbMsgRxBuf[channel][4] & 0xff) + ((usbMsgRxBuf[channel][5] & 0xff) << 8);
        int value = (usbMsgRxBuf[channel][6] & 0xff) + ((usbMsgRxBuf[channel][7] & 0xff) << 8) + ((usbMsgRxBuf[channel][8] & 0xff) << 16) + ((usbMsgRxBuf[channel][9] & 0xff) << 24);

        motorAnt[channel][id][index] = value;

//        /* Monitor Task */
//        for (int i = 1; i <= 120; i++)
//        {
//            /* If Tx Buffer is Empty, then append a reading message. */
//            if (isTxBufferEmpty(channel))
//            {
//                if (targetMonitorFlagAnt[channel][i] == 1)
//                {
//                    txBufferAppendCAN(channel, FUNC_TSDO, i, AntStatusWordIndex, AntReadSubIndex, 0);
//                    if ((motorAnt[channel][i][AntStatusWordIndex] & STATUS_TARGET_REACHED) == STATUS_TARGET_REACHED)
//                    {
//                        targetMonitorCounter++;
//                        if (targetMonitorCounter > 5)
//                        {
//                            targetMonitorCounter = 0;
//                            targetMonitorFlagAnt[channel][i] = 0;
//                            targetReachedFlagAnt[channel][i] = 1;
//                            EventCallback.onTargetReachedCallback(i, 0);
//                            Log.i("motion", "thread pos reached");
//                        }
//                    }
//                }
//            }
//        }
    }

    private boolean isTxBufferEmpty(int channel)
    {
        if (txBufferHead[channel] != txBufferTail[channel])
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    private void rxBufferAnalysisRS485(int channel)
    {
        int fucnCode = usbMsgRxBuf[channel][0] & 0xff;
        int index = (usbMsgRxBuf[channel][1] & 0xff);
        int id = (usbMsgRxBuf[channel][2] & 0xff);
        int subid = (usbMsgRxBuf[channel][3] & 0xff);
        int value = (usbMsgRxBuf[channel][4] & 0xff) + ((usbMsgRxBuf[channel][5] & 0xff) << 8) + ((usbMsgRxBuf[channel][6] & 0xff) << 16) + ((usbMsgRxBuf[channel][7] & 0xff) << 24);

        if (fucnCode == BeeFuncReadSDO_OK)
        {
            motorBee[channel][id][subid][index] = value;
            Log.i("usb", "rs485 read ok:"+channel);
        }

    }

    public int getChannelType(int channel)
    {
        return connectionType[channel];
    }

    public boolean isChannelTypeCAN(int channel)
    {
//        Log.i("usb", "connectionType" + connectionType[channel]);
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean isChannelTypeRS485(int channel)
    {
        Log.i("usb", "connectionType" + connectionType[channel]);
        if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public void waitUSBReady()
    {
        while (threadRunFlag == 0)
        {
            SystemClock.sleep(100);
            Log.i("usb", "wait ready");
        }
    }

    /*
     * set running current
     * value : 0-1500 for Ant 0-3300 for Bee
     * id : 1 - 120 for Ant, 0-31 for Bee
     * subid: 0 for Ant & Bee, 0-7 for Elephant
     * */
    public void setCurrentRun(int channel, int id, int subid, int value)
    {
//        if (connectionType[channel]==_CONNECTION_TYPE_CAN)
//        {
//            motorAnt[channel][id][AntStepperCurrentRunIndex] = value;
//            txBufferAppend(channel,FUNC_TSDO, id, AntStepperCurrentRunIndex, AntWriteSubIndex, value);
//        }
//        else if (connectionType[channel]==_CONNECTION_TYPE_RS485)
//        {
//            motorBee[channel][id][subid][BeeStepperCurrentRunIndex] = value;
//            txBufferAppend(channel,BeeFuncWriteSDO, id, subid, BeeStepperCurrentRunIndex, value);
//        }
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperCurrentRunIndex, AntWriteSubIndex, value);
        }
        if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeStepperCurrentRunIndex, value);
        }
    }

    /*
     * Set Keeping Current, when speed is 0.
     * id : 1 - 120 for Ant, 0-31 for Bee
     * subid: 0 for Ant & Bee, 0-7 for Elephant
     * value : 0-1500 for Ant, 0-3300 for Bee
     * */
    public void setCurrentKeep(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperCurrentKeepIndex, AntWriteSubIndex, value);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeStepperCurrentKeepIndex, value);
        }
    }

    /*
     * Set Speed
     * In Profile Position Mode, Speed is a positive number, range from 0 to 2000(according to motor's performace)
     * In Profile Velocity Mode, Speed has directions, + or - means two diretions.
     *  */
    public void setSpeed(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperRunVelIndex, AntWriteSubIndex, value);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeTargetVelocityIndex, value);
        }
    }

    /*
     * set the Acc and Dec time
     * unit: ms
     * range: value > 0, 200ms to 2000ms performs better
     * */
    public void setAccTime(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperAccTimeIndex, AntWriteSubIndex, value);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeProfileAccTimeIndex, value);
        }
    }

    /*
     * Set Operation Mode:
     * */
    public void setOpMode(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntModesofOperationIndex, AntWriteSubIndex, value);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeOperationModeIndex] = value;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeOperationModeIndex, value);
        }
    }

    /*
     * Enter Homing Mode
     * */
    public void setOpModeHoming(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            motorAnt[channel][id][AntModesofOperationIndex] = OPMODE_HOMING;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntModesofOperationIndex, AntWriteSubIndex, OPMODE_HOMING);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeOperationModeIndex] = OPMODE_HOMING;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeOperationModeIndex, OPMODE_HOMING);
        }
    }

    /*
     * Enter Homing Mode
     * */
    public void setOpmodeProfilePosition(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            motorAnt[channel][id][AntModesofOperationIndex] = OPMODE_PROFILE_POSITION;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntModesofOperationIndex, AntWriteSubIndex, OPMODE_PROFILE_POSITION);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeOperationModeIndex] = OPMODE_HOMING;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeOperationModeIndex, OPMODE_HOMING);
        }
    }


    /*
     * Set Homing Direction for Homing Mode
     * value can be 1 or -1
     * */
    public void setHomingDir(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            motorAnt[channel][id][AntStepperHomeDirIndex] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperHomeDirIndex, AntWriteSubIndex, value);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeHomingDirIndex] = value;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeHomingDirIndex, value);
        }
    }

    public void setHomingDirPositive(int channel, int id, int subid)
    {
        int value = 1;
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {

            motorAnt[channel][id][AntStepperHomeDirIndex] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperHomeDirIndex, AntWriteSubIndex, value);

        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeHomingDirIndex] = value;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeHomingDirIndex, value);
        }
    }

    public void setHomingDirNegative(int channel, int id, int subid)
    {
        int value = -1;
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {

            motorAnt[channel][id][AntStepperHomeDirIndex] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperHomeDirIndex, AntWriteSubIndex, value);

        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeHomingDirIndex] = value;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeHomingDirIndex, value);
        }
    }

    /*
     * Set Homing Sensor trigger Level
     * value can be 0 or 1
     * */
    public void setHomingLevel(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {

            motorAnt[channel][id][AntStepperHomeLevelIndex] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperHomeLevelIndex, AntWriteSubIndex, value);

        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeHomingLevelIndex] = value;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeHomingLevelIndex, value);
        }
    }

    public void setHomingLevelHigh(int channel, int id, int subid)
    {
        int value = 1;
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {

            motorAnt[channel][id][AntStepperHomeLevelIndex] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperHomeLevelIndex, AntWriteSubIndex, value);

        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeHomingLevelIndex] = value;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeHomingLevelIndex, value);
        }
    }

    public void setHomingLevelLow(int channel, int id, int subid)
    {
        int value = 0;
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            motorAnt[channel][id][AntStepperHomeLevelIndex] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperHomeLevelIndex, AntWriteSubIndex, value);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeHomingLevelIndex] = value;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeHomingLevelIndex, value);
        }
    }

    /*
     * set Enable
     * value can 0 or 1
     * 0- disable
     * 1- enable
     * */
    public void setEnable(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {

            motorAnt[channel][id][AntControlWordIndex] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntControlWordIndex, AntWriteSubIndex, value);

        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeControlWordIndex] = value;
            txBufferAppendRS485(channel, BeeFuncReadSDO, id, subid, BeeControlWordIndex, value);
        }
    }

    /*
     * Save Parameters to Board Flash Memory
     * */
    public void saveParameters(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntMemoryIndex, AntWriteSubIndex, 1);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncOperationSDO, id, subid, BeeMemoryIndex, 1);
        }
    }

    /* set target pos for profile position mode */
    public void setPos(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            motorAnt[channel][id][AntStepperRunPosIndex] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperRunPosIndex, AntWriteSubIndex, value);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeTargetPositionIndex] = value;
            targetMonitorFlagBee[channel][id][subid] = 1;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeTargetPositionIndex, value);
        }
    }

    public int getTargetPos(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStepperRunPosIndex, AntReadSubIndex, 0);
            return motorAnt[channel][id][AntStepperRunPosIndex];
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncReadSDO, id, subid, BeeTargetPositionIndex, 0);
            return motorBee[channel][id][subid][BeeTargetPositionIndex];
        }
        return 0;
    }

    public int getCurrentPos(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntActualPositionIndex, AntReadSubIndex, 0);
            return motorAnt[channel][id][AntActualPositionIndex];
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncReadSDO, id, subid, BeeActualPositionIndex, 0);
            return motorBee[channel][id][subid][BeeActualPositionIndex];
        }
        return 0;
    }

    public void setHeartBeatRate(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            motorAnt[channel][id][AntHeartBeatRateIndex] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntHeartBeatRateIndex, AntWriteSubIndex, value);
        }
    }

    public int waitPos(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            if (targetReachedFlagAnt[channel][id] == 1)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            if (motorBee[channel][id][subid][BeeActualPositionIndex] == motorBee[channel][id][subid][BeeTargetPositionIndex])
            {
                return 1;
            }
            else
            {
                txBufferAppendRS485(channel, BeeFuncReadSDO, id, subid, BeeActualPositionIndex, 0);
                return 0;
            }
        }
        return -1;
    }

    /* Value can be:
     * 0 or 1
     *  */
    public void setIoOut(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            motorAnt[channel][id][AntIO_OUT_Index] = value;
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntIO_OUT_Index, AntWriteSubIndex, value);
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeIoOutIndex] = value;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeIoOutIndex, value);
        }
    }

    /*
     * return value:
     * bit0 - Homing Sensor(0x01)
     * bit1 - Button(0x02)
     * */
    public int getIoIn(int channel, int id, int subid)
    {
        int value = 0;
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStatusWordIndex, AntReadSubIndex, 0);
            if ((motorAnt[channel][id][AntStatusWordIndex] & STATUS_IO_INPUT) == STATUS_IO_INPUT)
            {
                value |= 0x01;
            }
            if ((motorAnt[channel][id][AntStatusWordIndex] & STATUS_IO_INPUT2) == STATUS_IO_INPUT2)
            {
                value |= 0x02;
            }
            return value;
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncReadSDO, id, subid, BeeIoInIndex, 0);

            return motorBee[channel][id][subid][BeeIoInIndex];
        }
        return -1;
    }

    public void setOnTargetReachedListener(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            targetMonitorFlagAnt[channel][id] = 1;
            targetReachedFlagAnt[channel][id] = 0;
            motorAnt[channel][id][AntStatusWordIndex] &= ~STATUS_TARGET_REACHED;
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            targetMonitorFlagBee[channel][id][subid] = 1;
            targetReachedFlagBee[channel][id][subid] = 0;
            motorBee[channel][id][subid][AntStatusWordIndex] &= ~STATUS_TARGET_REACHED;
        }
    }

    public int getStatus(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_CAN)
        {
            txBufferAppendCAN(channel, FUNC_TSDO, id, AntStatusWordIndex, AntReadSubIndex, 0);

            return motorAnt[channel][id][AntStatusWordIndex];
        }
        else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncReadSDO, id, subid, BeeStatusWordIndex, 0);

            return motorBee[channel][id][subid][BeeStatusWordIndex];
        }
        return -1;
    }

    public void waitTargetReached(int channel, int id, int subid, int checkLimit, int timeout)
    {
        int status = 0;
        int st = 0;
        while (status < checkLimit)
        {
            if (connectionType[channel] == _CONNECTION_TYPE_CAN)
            {
                txBufferAppendCAN(channel, FUNC_TSDO, id, AntStatusWordIndex, AntReadSubIndex, 0);

                if ((motorAnt[channel][id][AntStatusWordIndex] & STATUS_TARGET_REACHED) == STATUS_TARGET_REACHED)
                {
                    status++;
                }
            }
            else if (connectionType[channel] == _CONNECTION_TYPE_RS485)
            {
                txBufferAppendRS485(channel, BeeFuncReadSDO, id, subid, BeeStatusWordIndex, 0);

                if ((motorBee[channel][id][subid][AntStatusWordIndex] & STATUS_TARGET_REACHED) == STATUS_TARGET_REACHED)
                {
                    status++;
                }
            }
            st++;
            if (st > timeout)
            {
                Log.i("usb", "wait time out");
                break;
            }
            SystemClock.sleep(100);
        }
    }
    /* Methods for Peg(Temperature Control Board) */
    public void setPegTargetTemp(int channel, int id, int subid,int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeTempTargetTempIndex] = value;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeTempTargetTempIndex, value);
        }
    }

    public int getPegTargetTemp(int channel, int id, int subid)
    {
        /* Now, we onle have temperature conntrol board with RS485 interface */
        if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncReadSDO, id, subid, BeeTempTargetTempIndex, 0);
            return motorBee[channel][id][subid][BeeTempTargetTempIndex];
        }
        else
            return -1;
    }

    public int getPegActualTemp(int channel, int id, int subid)
    {
        /* Now, we onle have temperature conntrol board with RS485 interface */
        if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            txBufferAppendRS485(channel, BeeFuncReadSDO, id, subid, BeeTempActualTempIndex, 0);
            return motorBee[channel][id][subid][BeeTempActualTempIndex];
        }
        else
            return -1;
    }

    public void setPegPowerOn(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeTempControlWordIndex] = 1;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeTempControlWordIndex, 1);
        }
    }

    public void setPegPowerOff(int channel, int id, int subid)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeTempControlWordIndex] = 0;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeTempControlWordIndex, 0);
        }
    }
    /* value: 100 = 1 Degree, and 1 = 0.01 Degree
    * Cooler will turn on when AntualTemp - TargetTemp > value
    * Cooler will turn off when AntualTemp - TargetTemp < -value
    * */
    public void setPegTriggerRange(int channel, int id, int subid, int value)
    {
        if (connectionType[channel] == _CONNECTION_TYPE_RS485)
        {
            motorBee[channel][id][subid][BeeTempTempOffsetIndex] = 0;
            txBufferAppendRS485(channel, BeeFuncWriteSDO, id, subid, BeeTempTempOffsetIndex, 0);
        }
    }
}
