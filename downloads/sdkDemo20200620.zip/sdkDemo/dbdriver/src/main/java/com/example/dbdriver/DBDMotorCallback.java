package com.example.dbdriver;

public interface DBDMotorCallback
{
    void onTargetReachedCallback(int id, int subid);
}
